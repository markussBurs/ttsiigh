﻿namespace sessia
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(69, 9);
            label1.Name = "label1";
            label1.Size = new Size(94, 34);
            label1.TabIndex = 0;
            label1.Text = "Группа";
            label1.Click += label1_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button1.Location = new Point(12, 62);
            button1.Name = "button1";
            button1.Size = new Size(397, 50);
            button1.TabIndex = 2;
            button1.Text = "Ввод списка группы";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.Location = new Point(12, 129);
            button2.Name = "button2";
            button2.Size = new Size(397, 50);
            button2.TabIndex = 3;
            button2.Text = "Ввод списка предметов";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button3.Location = new Point(12, 200);
            button3.Name = "button3";
            button3.Size = new Size(397, 50);
            button3.TabIndex = 4;
            button3.Text = "Ввод оценок студентов";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button4.Location = new Point(12, 299);
            button4.Name = "button4";
            button4.Size = new Size(397, 50);
            button4.TabIndex = 5;
            button4.Text = "Показать результаты сессии";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Impact", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button5.Location = new Point(12, 355);
            button5.Name = "button5";
            button5.Size = new Size(397, 50);
            button5.TabIndex = 6;
            button5.Text = "Рассчитать стипендию";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click_1;
            // 
            // button6
            // 
            button6.Font = new Font("Impact", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button6.Location = new Point(321, 411);
            button6.Name = "button6";
            button6.Size = new Size(88, 31);
            button6.TabIndex = 7;
            button6.Text = "Выход";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDark;
            ClientSize = new Size(421, 450);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Результаты сессии и расчет стипендии";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
    }
}
